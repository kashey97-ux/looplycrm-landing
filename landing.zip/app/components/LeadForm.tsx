"use client";

import DemoForm from "./DemoForm";

export default function LeadForm() {
  return <DemoForm intent="demo" />;
}

